type BlogWithFirstDetailsDto = {
  id: number;
  title: string;
  firstDetails: string | null;
  firstImageUrl: string | null;
};
