export const PageAction = {
  view: "view",
  add: "add",
  edit: "edit",
  delete: "delete",
};
