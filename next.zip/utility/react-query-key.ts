import React from "react";

export const ReactQueryKey = {
  blogs: "blogs",
  blogsView: "blogsView",
  user: "user",
  tags: "tags",
  hireme: "hireme",
};
