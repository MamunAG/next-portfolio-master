import React from "react";

export default function Page() {
  return <div>Page</div>;
}
