import React from "react";
import AboutClients from "../about/components/AboutClients";

export default function Services() {
  return (
    <div className="mt-[-10px] sm:mt-[-60px] ">
      <AboutClients />
    </div>
  );
}
