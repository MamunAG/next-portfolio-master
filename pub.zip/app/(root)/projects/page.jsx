import ProjectsGrid from "./components/ProjectsGrid";
function ProjectsPage() {
  return (
    <>
      <div className="container mx-auto">
        <ProjectsGrid></ProjectsGrid>
      </div>
    </>
  );
}

export default ProjectsPage;
