-- AlterTable
ALTER TABLE "User" ADD COLUMN     "role" TEXT;
