/*
  Warnings:

  - You are about to drop the column `masterId` on the `BlogTags` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "BlogTags" DROP COLUMN "masterId";
