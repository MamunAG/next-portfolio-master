// interface IOneSignalOneSignal {
// 	Slidedown: IOneSignalSlidedown;
// 	Notifications: IOneSignalNotifications;
// 	Session: IOneSignalSession;
// 	User: IOneSignalUser;
// 	Debug: IOneSignalDebug;
// 	login(externalId: string, jwtToken?: string): Promise<void>;
// 	logout(): Promise<void>;
// 	init(options: IInitObject): Promise<void>;
// 	setConsentGiven(consent: boolean): Promise<void>;
// 	setConsentRequired(requiresConsent: boolean): Promise<void>;
// }
